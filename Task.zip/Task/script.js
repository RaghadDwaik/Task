document.addEventListener('DOMContentLoaded', function () {
    const blobContainer = document.getElementById('blobContainer');
    const blobs = [];
    const blobSize = 40; 
    function createBlob() {
        const blob = document.createElement('div');
        blob.classList.add('blob');
        blob.style.backgroundColor = getRandomColor();
        const maxX = blobContainer.offsetWidth - blobSize;
        const maxY = blobContainer.offsetHeight - blobSize;
        blob.style.left = getRandomPosition(maxX) + 'px';
        blob.style.top = getRandomPosition(maxY) + 'px';
        blob.addEventListener('click', moveBlob);
        blobContainer.appendChild(blob);
        blobs.push(blob);
    }

    function getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    function getRandomPosition(max) {
        return Math.floor(Math.random() * max); 
    }

    function moveBlob(event) {
        const blob = event.target;
        const maxX = blobContainer.offsetWidth - blobSize;
        const maxY = blobContainer.offsetHeight - blobSize;
        const newX = getRandomPosition(maxX);
        const newY = getRandomPosition(maxY);
        blob.style.position = 'absolute';
        animateBlob(blob, newX, newY);
    }

    function animateBlob(blob, endX, endY) {
        const startX = parseInt(blob.style.left, 10);
        const startY = parseInt(blob.style.top, 10);
        const distanceX = endX - startX;
        const distanceY = endY - startY;
        const frames = 60;
        const interval = 1000 / frames;
        let currentFrame = 0;

        function step() {
            currentFrame++;
            if (currentFrame <= frames) {
                const newX = startX + (distanceX / frames) * currentFrame;
                const newY = startY + (distanceY / frames) * currentFrame;
                blob.style.left = newX + 'px';
                blob.style.top = newY + 'px';
                checkCollision(blob);
                requestAnimationFrame(step);
            }
        }

        requestAnimationFrame(step);
    }

    

    let counter = 0;
    const interval = setInterval(function () {
        if (counter < 3) {
            createBlob();
            counter++;
        } else {
            clearInterval(interval);
        }
    }, 1000);
});
